package com.example.osama.ministryofinteriorproject;

import android.app.ProgressDialog;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;
import android.widget.Toast;

import com.example.osama.ministryofinteriorproject.Adapter.FishersAdapter;
import com.example.osama.ministryofinteriorproject.Adapter.FishersOnSeaAdapter;
import com.example.osama.ministryofinteriorproject.Adapter.ShipsAdapter;
import com.example.osama.ministryofinteriorproject.Common.Common;
import com.example.osama.ministryofinteriorproject.Database.MySQLiteHelper;
import com.example.osama.ministryofinteriorproject.Model.Fisher;
import com.example.osama.ministryofinteriorproject.Model.InsideSea;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import uk.co.chrisjenx.calligraphy.CalligraphyConfig;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

import static com.example.osama.ministryofinteriorproject.Common.Common.fisherArrayList;

public class FishersOnSeaActivity extends AppCompatActivity implements SearchView.OnQueryTextListener{

    RecyclerView recyclerView;
    ArrayList<Fisher> fisherList;
    FishersOnSeaAdapter adapter;

    MySQLiteHelper mySQLiteHelper;
    ProgressDialog progressDialog;
    DatabaseReference table_Onsea;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/Monadi.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build());
        setContentView(R.layout.activity_fishers_on_sea);

        getSupportActionBar().setTitle("بيانات الصيادين داخل البحر");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        showDialog();
        recyclerView = findViewById(R.id.fishers_list);


        mySQLiteHelper = new MySQLiteHelper(getApplicationContext());
        fisherList = new ArrayList<>();
        fisherList.addAll(mySQLiteHelper.getAllFishers());

        recyclerView.setLayoutManager(new LinearLayoutManager(FishersOnSeaActivity.this));
        adapter = new FishersOnSeaAdapter(FishersOnSeaActivity.this,fisherList);
        recyclerView.setAdapter(adapter);
        hideDialog();


    }
    public void showDialog() {
        progressDialog = new ProgressDialog(FishersOnSeaActivity.this);
        progressDialog.setMessage("تحميل ....");
        progressDialog.setCancelable(false);
        progressDialog.show();
    }

    public void hideDialog() {
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) searchItem.getActionView();
        searchView.setOnQueryTextListener(this);
        searchView.setQueryHint("البحث");
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onQueryTextSubmit(String s) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String s) {
        ArrayList<Fisher> arrayList = new ArrayList<>();

        for(Fisher fisher : fisherList){
            if(fisher.getId().toLowerCase().contains(s.toLowerCase())){
                arrayList.add(fisher);
            }
        }

        adapter = new FishersOnSeaAdapter(getApplicationContext(),arrayList);
        adapter.notifyDataSetChanged();
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(adapter);
        return true;
    }
}
